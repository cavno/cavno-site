// 公理组合矩阵 —— 微信小程序逻辑
const { LAWS, STANCE, C } = require('./data.js');

const LAWMETA = { id:{n:'同一律',f:'A=A',c:'#1d4e5f'}, ct:{n:'矛盾律',f:'¬(A∧¬A)',c:'#6d4a8f'}, ex:{n:'排中律',f:'A∨¬A',c:'#3f7a52'}, re:{n:'充足理由律',f:'PSR',c:'#b8893a'} };
const LK = ['id','ct','ex','re'];
const VALUES = ['keep','keepmax','weaken','reject','limit','suspend','na'];
const VLAB = { keep:'持守',keepmax:'极致',weaken:'松动',reject:'否弃',limit:'限定',suspend:'悬置',na:'不涉' };
const VSHORT = { keep:'守',keepmax:'极',weaken:'松',reject:'弃',limit:'限',suspend:'悬',na:'—' };
const PIP = { keep:'#2e8b57',keepmax:'#2e8b57',weaken:'#cf3b2e',reject:'#cf3b2e',limit:'#d6a500',suspend:'#d6a500',na:'#c9bda8' };
const RING = { keepmax:1,reject:1,suspend:1 };
const HOLLOW = { na:1 };
const INT = { keepmax:2,keep:1,limit:0,suspend:-0.6,weaken:-1,reject:-2,na:0 };

function pipStyle(v){
  if(HOLLOW[v]) return 'border:3rpx solid ' + PIP[v] + ';background:transparent';
  if(RING[v])   return 'background:' + PIP[v] + ';box-shadow:0 0 0 3rpx #faf4e6,0 0 0 6rpx ' + PIP[v];
  return 'background:' + PIP[v];
}
function hexA(hex,a){ const n=parseInt(hex.slice(1),16); return 'rgba('+(n>>16&255)+','+(n>>8&255)+','+(n&255)+','+a+')'; }
function sigOf(s){ return s.id+'|'+s.ct+'|'+s.ex+'|'+s.re; }
function sigShort(cfg){ return '同'+VSHORT[cfg.id]+'·矛'+VSHORT[cfg.ct]+'·排'+VSHORT[cfg.ex]+'·理'+VSHORT[cfg.re]; }

const ISMS = {
 'keepmax|keep|keep|keep':{name:'巴门尼德式绝对一元',blurb:'四律全开＋思维=存在，世界冻为不动、不可分的「一」。'},
 'keep|keepmax|limit|keep':{name:'亚里士多德式形式逻辑',blurb:'立三律，以潜能/现实与论域分层绕过排中（明日海战）。'},
 'keep|keepmax|keepmax|keep':{name:'爱利亚-麦加拉归谬',blurb:'把矛盾律、排中律推到极致，用归谬反证运动与「多」不可能。'},
 'keep|keep|keep|keepmax':{name:'理性论 · 必然主义',blurb:'守全部逻辑律，并把充足理由律推到极致——凡存在皆有理由，故一切皆必然。'},
 'keep|keep|keep|keep':{name:'古典理性 · 常识',blurb:'四律皆守，理由律不过度——西方理性的「默认」主流。'},
 'keep|keep|keep|reject':{name:'因果怀疑论（休谟式）',blurb:'守逻辑而砍断必然因果：因果只是习惯，PSR 失去理性根。'},
 'keep|keep|keep|limit':{name:'批判 / 实证（限定理由）',blurb:'逻辑普遍有效，但充足理由律只在现象界 / 实证规律内有效。'},
 'keep|keep|keep|weaken':{name:'理由松动（意志·情感优先）',blurb:'守逻辑，但在理性之外另立根据（意志、情感、心的理由）。'},
 'suspend|suspend|suspend|suspend':{name:'怀疑主义 · 悬置',blurb:'四律皆悬，判断全盘停机（epoché）。'},
 'weaken|reject|reject|keep':{name:'辩证法（黑格尔式）',blurb:'抽象同一空洞，矛盾成为自我推进的发动机。'},
 'weaken|reject|weaken|keep':{name:'辩证唯物（马克思式）',blurb:'矛盾落到物质生产与阶级的现实运动。'},
 'reject|weaken|weaken|keep':{name:'流变 / 过程（赫拉克利特式）',blurb:'否同一而保留逻各斯之理由：万物流变、对立同一。'},
 'keep|weaken|weaken|keep':{name:'唯心辩证发端 / 经验逻辑',blurb:'守同一与理由，松动矛盾与排中（费希特的自我设定；密尔视逻辑为经验概括）。'},
 'weaken|weaken|weaken|keep':{name:'绝对唯心 · 同一哲学',blurb:'关系性思维自相矛盾，统一于「绝对」（谢林、布拉德雷）。'},
 'reject|weaken|weaken|reject':{name:'存在论解构（海德格尔式）',blurb:'存在非对象，A=A 不足以解释存在；玫瑰无 why。'},
 'weaken|weaken|weaken|reject':{name:'存在主义 / 权力意志',blurb:'自由无据、存在是多余的；真理是（权力）意志的产物。'},
 'na|na|na|reject':{name:'荒诞（加缪式）',blurb:'世界对人索要理由的呼声保持沉默。'},
 'reject|weaken|reject|reject':{name:'解构（德里达式）',blurb:'二元对立可拆，意义永远延异、从不自我同一。'},
 'reject|na|weaken|weaken':{name:'差异哲学（德勒兹式）',blurb:'差异在先，同一只是被生产出的效果。'},
 'weaken|na|weaken|reject':{name:'谱系学 / 权力（福柯式）',blurb:'真理由历史性的权力-知识体制生产，无中立奠基。'},
 'keep|keep|reject|na':{name:'直觉主义',blurb:'未证明 ≠ 假，撤排中；数学因此分叉。'},
 'keep|keep|weaken|na':{name:'多值 / 模糊逻辑',blurb:'第三值与连续程度的真，弱化排中。'},
 'keep|reject|keep|na':{name:'次协调 / 双面真理',blurb:'让矛盾不再爆炸，并主张某些矛盾为真。'},
 'keep|keepmax|keepmax|na':{name:'逻辑主义（弗雷格式）',blurb:'以概念文字把古典三律推至形式精确的极致。'},
 'keep|keepmax|keep|na':{name:'类型论 / 分层（罗素式）',blurb:'用类型分层消解悖论，以保住矛盾律。'},
 'keep|keep|keep|na':{name:'元逻辑 / 分析常识',blurb:'守经典逻辑，对形而上学的「理由」存而不论。'},
 'limit|limit|limit|limit':{name:'语言批判 · 约定论',blurb:'四律整体降为「思之语法」/ 语言框架的约定（维特根斯坦、卡尔纳普）。'},
 'limit|limit|limit|na':{name:'逻辑可修正（蒯因式）',blurb:'整体论：原则上连逻辑律也可为保全经验而修订。'},
 'keepmax|keep|keep|weaken':{name:'意志优先经院（司各脱式）',blurb:'个体性（haecceitas）与意志高于理智。'},
 'weaken|keep|keep|weaken':{name:'唯名论（奥卡姆式）',blurb:'否认共相之实在；神之意志高于理性。'},
 'weaken|keep|keep|keepmax':{name:'机械决定论（霍布斯式）',blurb:'唯名＋彻底机械必然，推理即计算。'},
 'weaken|reject|reject|keepmax':{name:'对立重合（库萨式）',blurb:'在无限中矛盾与排中重合——黑格尔的先声。'},
 'weaken|weaken|weaken|keepmax':{name:'无限泛神（布鲁诺式）',blurb:'承库萨之对立重合，宇宙无限、神即自然。'},
 'limit|keep|keep|keepmax':{name:'否定神学 / 流溢（普罗提诺式）',blurb:'太一超越言说与逻辑，万物由之流溢。'},
 'limit|limit|limit|keepmax':{name:'神秘主义超逻辑（埃克哈特式）',blurb:'神性超越一切区分，逻辑止于神秘之巅。'},
 'keep|weaken|keep|keep':{name:'给非存在留位（柏拉图式）',blurb:'以相异性容纳「非存在」，够说出「假」与「差异」。'},
 'keep|weaken|weaken|weaken':{name:'相对 · 多元 · 实存',blurb:'真理随人/处境而异（智者—克尔凯郭尔—詹姆斯，跨越两千余年同型）。'},
 'keep|keep|weaken|weaken':{name:'工具主义（杜威式）',blurb:'真理＝「有保证的可断言性」，可错而多元。'},
 'reject|weaken|weaken|weaken':{name:'绵延 / 生命流（柏格森式）',blurb:'不可分的生成反对把时间空间化的静态同一。'},
 'weaken|weaken|weaken|na':{name:'含混身体现象学（梅洛庞蒂式）',blurb:'身体—世界的含混松动了非此即彼的界限。'},
 'limit|limit|limit|weaken':{name:'临界 · 大全（雅斯贝尔斯式）',blurb:'超越主客的「大全」只能以密码暗示。'},
 'na|keep|keep|reject':{name:'思辨实在 / 非理由（梅亚苏式）',blurb:'撤充足理由律、偶然为绝对，却反过来论证矛盾律成立。'}
};
function ismFor(sig,cfg){ return ISMS[sig] || { name:sigShort(cfg)+' 倾向', blurb:'此构型尚无单一命名——由其四律配置定义的一种混合倾向。' }; }
function quadColor(cfg){
  const ctK=(cfg.ct==='keep'||cfg.ct==='keepmax'), exK=(cfg.ex==='keep'||cfg.ex==='keepmax');
  if(ctK&&exK) return '#1d4e5f';
  if(ctK&&!exK) return '#3f7a52';
  if(!ctK&&exK) return '#6d4a8f';
  return '#a73e2c';
}

// 聚类
const clusters = {};
Object.keys(C).forEach(id => { const s=C[id].s, sig=sigOf(s); if(!clusters[sig]) clusters[sig]={sig,cfg:{id:s.id,ct:s.ct,ex:s.ex,re:s.re},members:[]}; clusters[sig].members.push(id); });
const CL = Object.keys(clusters).map(k=>clusters[k]);
const NCONF = CL.length, TOTAL = Math.pow(7,4);

Page({
  data: {
    matrixHead: [], matrixRows: [], readout: {},
    nodes: [], regions: [], axis: {}, scatterW: 350, scatterH: 340, legend: [],
    panel: { type:'guide' }, pipKeys: [],
    sheetOpen: true,
    browseOpen: false, browseList: [],
    NCONF, TOTAL, EMPTY: TOTAL-NCONF
  },

  onLoad(){
    this.combo = { id:'any', ct:'any', ex:'any', re:'any' };
    this.selectedSig = null; this.selectedPhilo = null;
    this.layoutScatter();
    this.setData({
      pipKeys: VALUES.map(v=>({ l:VLAB[v], style:pipStyle(v) })),
      legend: [
        { l:'经典', d:hexA('#1d4e5f',.55), b:'#1d4e5f' },
        { l:'直觉主义系', d:hexA('#3f7a52',.55), b:'#3f7a52' },
        { l:'次协调系', d:hexA('#6d4a8f',.55), b:'#6d4a8f' },
        { l:'FDE/解构', d:hexA('#a73e2c',.55), b:'#a73e2c' }
      ]
    });
    this.buildMatrix();
    this.renderPanel();
  },

  // 星图布局（px，依屏宽）
  layoutScatter(){
    let W = 350; try { W = (wx.getSystemInfoSync().windowWidth || 350); } catch(e){}
    const pad = 12;
    const SW = W - pad*2, SH = Math.round(SW*0.96);
    const padL=28, padR=14, padT=26, padB=34;
    const xPos = cfg => padL + (((INT[cfg.id]+INT[cfg.ct]+INT[cfg.ex])/3)+2)/4*(SW-padL-padR);
    const yPos = cfg => (SH-padB) - (INT[cfg.re]+2)/4*(SH-padT-padB);
    const jit = sig => { let h=0; for(let i=0;i<sig.length;i++) h=(h*31+sig.charCodeAt(i))|0; return { dx:((h%1000)/1000-0.5)*22, dy:(((h>>10)%1000)/1000-0.5)*22 }; };
    this.nodesRaw = CL.map(c => {
      const j=jit(c.sig), x=xPos(c.cfg)+j.dx, y=yPos(c.cfg)+j.dy;
      const r=5+Math.sqrt(c.members.length)*3, col=quadColor(c.cfg);
      const ism=ismFor(c.sig,c.cfg);
      return { sig:c.sig, x, y, r, d:r*2, left:x-r, top:y-r,
        bg:hexA(col,.5), border:col, count:c.members.length,
        label: c.members.length>=3 ? ism.name.replace(/（.*）/,'') : '',
        labLeft:x-44, labTop:y+r+1, cls:'' };
    });
    const cx = xPos({id:'limit',ct:'limit',ex:'limit'});
    const cy = yPos({re:'limit'});
    this.scatterGeo = { SW, SH, padL, padR, padT, padB, cx, cy };
    this.curNodeCls = {}; this.nodesRaw.forEach(n=>this.curNodeCls[n.sig]='');
    this.setData({
      scatterW: SW, scatterH: SH, nodes: this.nodesRaw,
      axis: { vx:cx, vTop:padT, vH:SH-padT-padB, hy:cy, hLeft:padL, hW:SW-padL-padR,
              xr:SW-padR, xl:padL, yt:padT, yb:SH-padB-2, cx },
      regions: [
        { t:'必然主义·理性论', left:SW-padR-150, top:padT+8, w:150, align:'right' },
        { t:'辩证·思辨', left:padL, top:padT+8, w:140, align:'left' },
        { t:'分析·逻辑严格/弃理由', left:SW-padR-160, top:SH-padB-22, w:160, align:'right' },
        { t:'解构·虚无·存在', left:padL, top:SH-padB-22, w:150, align:'left' },
        { t:'怀疑·悬置/批判限定', left:cx-80, top:cy+6, w:160, align:'center' }
      ]
    });
  },

  comboConstrained(){ return LK.some(L=>this.combo[L]!=='any'); },
  matchedClusters(){ if(!this.comboConstrained()) return []; return CL.filter(c=>LK.every(L=> this.combo[L]==='any' || c.cfg[L]===this.combo[L])); },

  buildMatrix(){
    const head = [{ any:true, label:'任意' }].concat(VALUES.map(v=>({ style:pipStyle(v), label:VLAB[v] })));
    const rows = LK.map(L=>{
      const cells = [{ v:'any', char:'任意', on:(this.combo[L]==='any'), any:true, tint:'' }];
      VALUES.forEach(v=>{
        const on=(this.combo[L]===v);
        cells.push({ v, char:VSHORT[v], pip:pipStyle(v), on, tint: on?('border-color:'+PIP[v]+';background:'+hexA(PIP[v],.14)):'' });
      });
      return { law:L, name:LAWMETA[L].n, f:LAWMETA[L].f, c:LAWMETA[L].c, cells };
    });
    this.setData({ matrixHead: head, matrixRows: rows });
    this.renderReadout();
  },
  renderReadout(){
    const mc=this.matchedClusters(), philos=mc.reduce((s,c)=>s+c.members.length,0);
    const cur = LK.map(L=> this.combo[L]==='any' ? { any:true, n:LAWMETA[L].n } : { any:false, style:pipStyle(this.combo[L]) });
    this.setData({ readout: { constrained:this.comboConstrained(), mc:mc.length, philos, cur } });
  },

  refreshNodes(){
    const constrained=this.comboConstrained();
    const mset={}; if(constrained) this.matchedClusters().forEach(c=>mset[c.sig]=1);
    const patch={};
    this.nodesRaw.forEach((n,i)=>{
      let cls='';
      if(this.selectedSig){ cls = (n.sig===this.selectedSig)?'sel':'dim'; }
      else if(constrained){ cls = mset[n.sig]?'':'dim'; }
      if(this.curNodeCls[n.sig]!==cls){ patch['nodes['+i+'].cls']=cls; this.curNodeCls[n.sig]=cls; }
    });
    if(Object.keys(patch).length) this.setData(patch);
  },

  onCell(e){ this.setCombo(e.currentTarget.dataset.law, e.currentTarget.dataset.v); },
  setCombo(law,v){
    this.combo[law]=v; this.selectedSig=null; this.selectedPhilo=null;
    this.buildMatrix(); this.refreshNodes(); this.renderPanel(); this.openSheet();
  },
  onNode(e){ this.selectCluster(e.currentTarget.dataset.sig); },
  selectCluster(sig){
    this.selectedSig=sig; this.selectedPhilo=null;
    const cfg=clusters[sig].cfg; LK.forEach(L=>this.combo[L]=cfg[L]);
    this.buildMatrix(); this.refreshNodes(); this.renderPanel(); this.closeBrowse(); this.openSheet();
  },
  onPhilo(e){ this.selectPhilo(e.currentTarget.dataset.id); },
  selectPhilo(id){
    this.selectedPhilo=id; this.selectedSig=sigOf(C[id].s);
    const cfg=C[id].s; LK.forEach(L=>this.combo[L]=cfg[L]);
    this.buildMatrix(); this.refreshNodes(); this.renderPanel(); this.openSheet();
  },

  cfgRows(cfg){ return LK.map(L=>{ const v=cfg[L]; return { name:LAWMETA[L].n, f:LAWMETA[L].f, lab:VLAB[v], pip:pipStyle(v), color:HOLLOW[v]?'#6e6253':PIP[v] }; }); },
  renderPanel(){
    if(this.selectedPhilo){
      const id=this.selectedPhilo, n=C[id], sig=sigOf(n.s), ism=ismFor(sig,n.s);
      const same=clusters[sig].members.filter(m=>m!==id).map(m=>({ id:m, name:C[m].name }));
      this.setData({ panel:{ type:'philo', name:n.name, rep:n.rep, ismName:ism.name, sig, cfg:this.cfgRows(n.s), move:n.move, note:n.note, same } });
      return;
    }
    if(this.selectedSig){
      const c=clusters[this.selectedSig], ism=ismFor(c.sig,c.cfg);
      this.setData({ panel:{ type:'cluster', name:ism.name, blurb:ism.blurb, sigShort:sigShort(c.cfg), count:c.members.length, cfg:this.cfgRows(c.cfg), members:c.members.map(id=>({ id, name:C[id].name })) } });
      return;
    }
    if(this.comboConstrained()){
      const mc=this.matchedClusters().slice().sort((a,b)=>b.members.length-a.members.length);
      const philos=mc.reduce((s,c)=>s+c.members.length,0);
      const active=LK.filter(L=>this.combo[L]!=='any').map(L=>LAWMETA[L].n+'='+VLAB[this.combo[L]]).join(' · ');
      this.setData({ panel:{ type:'matched', active:active||'—', n:mc.length, philos,
        cards: mc.map(c=>({ sig:c.sig, name:ismFor(c.sig,c.cfg).name, count:c.members.length,
          pips:LK.map(L=>pipStyle(c.cfg[L])), sigShort:sigShort(c.cfg), members:c.members.map(id=>C[id].name).join('、') })) } });
      return;
    }
    this.setData({ panel:{ type:'guide' } });
  },

  doRandom(){ const c=CL[Math.floor(Math.random()*CL.length)]; this.selectCluster(c.sig); },
  openBrowse(){
    const list = CL.slice().sort((a,b)=>b.members.length-a.members.length).map(c=>({
      sig:c.sig, name:ismFor(c.sig,c.cfg).name, count:c.members.length,
      pips:LK.map(L=>pipStyle(c.cfg[L])), sigShort:sigShort(c.cfg), members:c.members.map(id=>C[id].name).join('、')
    }));
    this.setData({ browseList:list, browseOpen:true });
  },
  closeBrowse(){ if(this.data.browseOpen) this.setData({ browseOpen:false }); },
  onBrowsePick(e){ this.selectCluster(e.currentTarget.dataset.sig); },

  reset(){ LK.forEach(L=>this.combo[L]='any'); this.selectedSig=null; this.selectedPhilo=null; this.buildMatrix(); this.refreshNodes(); this.renderPanel(); },
  toggleSheet(){ this.setData({ sheetOpen: !this.data.sheetOpen }); },
  openSheet(){ if(!this.data.sheetOpen) this.setData({ sheetOpen:true }); },
  noop(){}
});
